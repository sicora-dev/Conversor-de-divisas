package com.mrh.conversordivisas

data class Cambio (
    //Cambiar por los parametros necesarios
    val simbolo1: String,
    val simbolo2: String,
    val quantity: Double,
    val resultado: Double
)
