package com.mrh.conversordivisas

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AppViewModel : ViewModel() {
    var history : LiveData<List<Cambio>> = MutableLiveData()
}